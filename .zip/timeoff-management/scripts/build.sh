#!/usr/bin/env sh

echo "This command npm install will install all packages in the system"
set +x
npm install 